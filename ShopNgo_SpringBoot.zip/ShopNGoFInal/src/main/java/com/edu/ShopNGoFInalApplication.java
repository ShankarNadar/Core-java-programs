package com.edu;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ShopNGoFInalApplication {

	public static void main(String[] args) {
		SpringApplication.run(ShopNGoFInalApplication.class, args);
	}

}
