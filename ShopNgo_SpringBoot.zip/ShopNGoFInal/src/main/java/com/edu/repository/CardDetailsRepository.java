
package com.edu.repository;

import java.util.Optional;

import javax.transaction.Transactional;

import org.springframework.data.jpa.repository.JpaRepository;

import org.springframework.stereotype.Repository;

import com.edu.dao.CardDetails;

@Repository
public interface CardDetailsRepository extends JpaRepository<CardDetails, Integer> {

	CardDetails save(CardDetails cardDetails);

	Optional<CardDetails> findByCardNumber(String cardNumber);

//	Optional<CardDetails> findByCardNumberAndCvv(String cardNumber, String cvv);

	

}