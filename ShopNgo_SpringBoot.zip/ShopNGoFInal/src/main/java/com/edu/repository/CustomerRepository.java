package com.edu.repository;



import java.sql.Date;

import javax.transaction.Transactional;
import javax.validation.Valid;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import com.edu.dao.Customer;

@Repository
public interface CustomerRepository extends JpaRepository<Customer, Integer>{


	public boolean existsByCustomerphoneno(String customerphoneno);

	public boolean existsByCustomeremailid(String customeremailid);

	public Customer findByCustomerphoneno(String customerphoneno);
	
	@Query(value="select * from Customer  where customerphoneno=:cname",nativeQuery = true)
	public Customer getCustomerByPhoneno(String cname);

	

	@Transactional
	@Modifying
	@Query(value="delete from Customer where customerphoneno=:cpno",nativeQuery = true)
	public void deleteCustomerByCustomerPhoneno(String cpno);
    
	
	@Transactional
	@Modifying
	@Query(value="update Customer set customerfirstname=:customerfirstname where customerphoneno=:cpno",nativeQuery = true)
	public void updateCustomerByCustomerPhoneno(String cpno, String customerfirstname);

	@Transactional
	@Modifying
	@Query(value="update Customer set customerlastname=:customerlastname where customerphoneno=:cpno",nativeQuery = true)
	public void updateCustomerLastname(String cpno, String customerlastname);

	@Transactional
	@Modifying
	@Query(value="update Customer set customerpassword=:customerpassword where customerphoneno=:cpno",nativeQuery = true)
	public void updateCustomerPassword(String cpno, String customerpassword);

	@Transactional
	@Modifying
	@Query(value="update Customer set customeremailid=:customeremailid where customerphoneno=:cpno",nativeQuery = true)
	public void updateCustomerEmailid(@Valid String cpno, String customeremailid);

	@Transactional
	@Modifying
	@Query(value="update Customer set customerdob=:customerdob where customerphoneno=:cpno",nativeQuery = true)
	public void updateCustomerdob(@Valid String cpno, Date customerdob);
	
	@Transactional
	@Modifying
	@Query(value="delete from Customer where customerid=:customerid",nativeQuery = true)
	public void deleteByCustomerid( @Param("customerid") Integer customerid);



}
