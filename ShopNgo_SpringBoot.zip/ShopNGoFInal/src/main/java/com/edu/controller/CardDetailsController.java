package com.edu.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.edu.dao.CardDetails;

import com.edu.service.CardDetailsService;


@RestController
@CrossOrigin(origins="http://localhost:4200")
public class CardDetailsController {

	
	@Autowired
	private  CardDetailsService cardDetailsService;
	
	
	@PostMapping("/saveCard")
	public ResponseEntity<CardDetails> saveCardDetails(@RequestBody CardDetails  cardDetails){
		CardDetails obj= cardDetailsService.savecarddetails(cardDetails);
		return new ResponseEntity<CardDetails>(obj,HttpStatus.CREATED);

		}
//	 @GetMapping("/validateCardDetails")
//	    public ResponseEntity<Boolean> validateCardDetails(@RequestParam String cardNumber, @RequestParam String cvv) {
//	        boolean isValid = cardDetailsService.validateCardDetails(cardNumber, cvv);
//	        return ResponseEntity.ok(isValid);
//	    }
	 
	 @GetMapping("/validateCardDetails")
	    public ResponseEntity<Boolean> validateCardDetails(@RequestParam String cardNumber,
	                                                       @RequestParam String cardHolderName,
	                                                       @RequestParam String expiryDate,
	                                                       @RequestParam String cvv) {
		 boolean isValid = cardDetailsService.validateCardDetails(cardNumber, cardHolderName, expiryDate, cvv);
	        return ResponseEntity.ok(isValid);
	    }
	
	
}