package com.edu.controller;

import java.io.IOException;
import org.springframework.data.domain.Sort;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RequestPart;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import com.edu.dao.ImageModel;
import com.edu.dao.ShopkeeperProduct;
import com.edu.service.ShopkeeperProductService;

@CrossOrigin(origins = "http://localhost:4200")
@RestController
public class ShopkeeperProductController {

	@Autowired
	private ShopkeeperProductService shopkeeperProductService; 
	
	@PostMapping("/saveShopkeeperProduct")
	public ResponseEntity<ShopkeeperProduct> saveShopkeeperProduct(@RequestBody ShopkeeperProduct shopkeeperproduct){
		ShopkeeperProduct obj= shopkeeperProductService.saveProduct(shopkeeperproduct);
		return new ResponseEntity<ShopkeeperProduct>(obj,HttpStatus.CREATED);

		}
	
	@PostMapping("/addNewProduct")
	public ShopkeeperProduct addNewProduct(@RequestPart("shopkeeperproduct") ShopkeeperProduct shopkeeperproduct,@RequestPart("imagefile")MultipartFile[]file) {
		
		//return productService.addProductImage(product);
		try {
			Set<ImageModel> images=uploadImage(file);
			shopkeeperproduct.setProductImages(images);
			return shopkeeperProductService.addProductImage(shopkeeperproduct);
		}catch (Exception e) {
			System.out.println(e.getMessage());
			return null;	
		}
		
		
		
	}
	public Set<ImageModel> uploadImage(MultipartFile[] multipartFiles) throws IOException{
		Set<ImageModel>imageModels=new HashSet<>();
		for(MultipartFile file:multipartFiles) {
			ImageModel imageModel=new ImageModel(
					file.getOriginalFilename(),
					file.getContentType(),
					file.getBytes()
					);
					imageModels.add(imageModel);
		}
		
		return imageModels;
		
	}
	
	
	@GetMapping("/getAllProducts")
    public List<ShopkeeperProduct> getAllProducts(@RequestParam(defaultValue = "") String searchKey) {
        Sort sort = Sort.by(Sort.Direction.ASC, "shopkeeperproductname");
        return shopkeeperProductService.getAllProducts(searchKey, sort);
    }
	@PutMapping("/shopkeeperproduct/{shopkeeperproductname}/shopkeeperproductquantity/{shopkeeperproductquantity}/shopkeeperproductprice/{shopkeeperproductprice}")
	public String updateProductByName(@PathVariable String shopkeeperproductname, @PathVariable Long shopkeeperproductquantity, @PathVariable Integer shopkeeperproductprice ) {
		 shopkeeperProductService.updateProductByName(shopkeeperproductname,shopkeeperproductquantity,shopkeeperproductprice);
		return "ShopkeeperProduct table is updated";
	}
	
	@DeleteMapping("/shopkeeperproduct/{shopkeeperproductname}")
	public String deleteProductByName(@PathVariable String shopkeeperproductname) {
		shopkeeperProductService.deleteProductByName(shopkeeperproductname);
		return "ShopkeeperProduct is deleted";
	}
	//image
	@GetMapping("/getProductDetailsById/{shopkeeperproductid}")
	public ShopkeeperProduct getProductDetailsById(@PathVariable("shopkeeperproductid") Integer shopkeeperproductid ) {
		return shopkeeperProductService.getProductDetailsById(shopkeeperproductid);
	}
	@DeleteMapping("/deleteproductById/{shopkeeperproductid}")
	public void deleteProductById(@PathVariable("shopkeeperproductid")Integer shopkeeperproductid) {
		shopkeeperProductService.deleteProductById(shopkeeperproductid);
	}
	
	@GetMapping("/getProductDetail/{isSingleProductCheckout}/{productId}")
	public List<ShopkeeperProduct> getProductDetail (@PathVariable(name="isSingleProductCheckout") boolean isSingleProductCheckout,@PathVariable(name="productId") Integer productId) {
		return  shopkeeperProductService.getProductDetail(isSingleProductCheckout,productId);
		
}
}
