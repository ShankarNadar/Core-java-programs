package com.edu.service;

import java.util.List;

import javax.validation.Valid;

import com.edu.dao.Admin;
import com.edu.error.GlobalException;

public interface AdminService {

	Admin saveAdmin(@Valid Admin admin) throws GlobalException;

	String deleteAdminByAdminname(String adminname) throws GlobalException;


	List<Admin> getAllAdmin();

	boolean loginAdmin(String adminname, String adminpassword);

	
	

}
