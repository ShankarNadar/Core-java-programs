
package com.edu.service;

import com.edu.dao.CardDetails;

public interface CardDetailsService {

	CardDetails savecarddetails(CardDetails cardDetails);

//	boolean validateCardDetails(String cardNumber, String cvv);


	boolean validateCardDetails(String cardNumber, String cardHolderName, String expiryDate, String cvv);

	

	

}
