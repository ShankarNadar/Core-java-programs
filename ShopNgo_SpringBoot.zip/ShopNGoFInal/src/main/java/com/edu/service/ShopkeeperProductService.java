package com.edu.service;

import java.util.List;

import org.springframework.data.domain.Sort;

import com.edu.dao.ShopkeeperProduct;

public interface ShopkeeperProductService {

	ShopkeeperProduct saveProduct(ShopkeeperProduct shopkeeperproduct);

	

	void updateProductByName(String shopkeeperproductname, Long shopkeeperproductquantity,
			Integer shopkeeperproductprice);

	void deleteProductByName(String shopkeeperproductname);
	
	ShopkeeperProduct addProductImage(ShopkeeperProduct product);

	ShopkeeperProduct getProductDetailsById(Integer shopkeeperproductid);

	void deleteProductById(Integer shopkeeperproductid);

	List<ShopkeeperProduct> getProductDetail(boolean isSingleProductCheckout, Integer productId);



	List<ShopkeeperProduct> getAllProducts(String searchKey, Sort sort);
}
