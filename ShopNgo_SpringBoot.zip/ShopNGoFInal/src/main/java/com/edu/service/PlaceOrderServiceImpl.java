package com.edu.service;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.edu.dao.PlaceOrder;
import com.edu.dao.ShopkeeperProduct;
import com.edu.error.GlobalException;
import com.edu.repository.CustomerRepository;
import com.edu.repository.PlaceOrderRepository;
import com.edu.repository.ShopkeeperProductRepository;

@Service
public class PlaceOrderServiceImpl implements PlaceOrderService {
	
	@Autowired
	 private PlaceOrderRepository  placeOrderRepository;
	
	@Autowired
	private CustomerRepository customerrepository;
	
	@Autowired
	private ShopkeeperProductRepository shopkeeperProductRepository;
	
	


	@Override
	public void savePlaceOrder(PlaceOrder placeorder, String phonenuumber, Integer produtid) throws GlobalException {
		double total;
		boolean isPresent= customerrepository.existsByCustomerphoneno(phonenuumber);
		
		if(isPresent) {
		      placeorder.setPlaceorderloginphonenumber(phonenuumber);
			
			//placeorder.setPlaceorderloginphonenumber(phonenuumber);
		
		}
		
		
		
		 ShopkeeperProduct product = shopkeeperProductRepository.findById(produtid).get();

		if (product!=null) {
		  //  ShopkeeperProduct shopkeeperProduct =new ShopkeeperProduct();
		    System.out.println(product);
		  //  System.out.println(shopkeeperProduct);

		    Integer productprice = product.getShopkeeperproductprice();
		   
		    total = placeorder.getPlaceorderquantity() * productprice;
		    
		    placeorder.setPlaceorderproductid(produtid);
		    placeorder.setPlaceorderproductname(product.getShopkeeperproductname());
		    placeorder.setPlaceorderactualprice(productprice);
		    product.setShopkeeperproductquantity(product.getShopkeeperproductquantity() - placeorder.getPlaceorderquantity());
		    placeorder.setPlaceorderpaymentStatus("not paid");
		    placeorder.setPlaceorderdeliverystatus("yet to delivered");
		} else {
		    throw new GlobalException("The product does not exist");
		}

	placeorder.setPlaceordertotalamount(total);

		
	placeOrderRepository.save(placeorder);
	}




	@Override
	public PlaceOrder getPlaceOrder() {
		// TODO Auto-generated method stub
		
		
		PlaceOrder lastOrder = placeOrderRepository.findFirstByOrderByPlaceorderidDesc();

        // If the last order is not null, return it; otherwise, handle the case
        if (lastOrder != null) {
            return lastOrder;
        } else {
            // Handle the case when there are no place orders in the database
            // For example, you can throw an exception or return null
            throw new RuntimeException("No place orders found.");
        }
	}




	@Override
	public List<PlaceOrder> getAllPlaceOrder() {
		
		return placeOrderRepository.findAll() ;
	}




	@Override
	public String updatePaymentStatus() {
		PlaceOrder lastOrder = placeOrderRepository.findFirstByOrderByPlaceorderidDesc();
		System.out.println(lastOrder.getPlaceorderpaymentStatus());
         lastOrder.setPlaceorderpaymentStatus("paid");
         placeOrderRepository.save(lastOrder);
		return "Updated";
	}

}