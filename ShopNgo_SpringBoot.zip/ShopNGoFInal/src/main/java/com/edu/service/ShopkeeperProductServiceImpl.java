package com.edu.service;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.edu.dao.ShopkeeperProduct;
import com.edu.repository.ShopkeeperProductRepository;
import org.springframework.data.domain.Sort;

@Service
public class ShopkeeperProductServiceImpl implements ShopkeeperProductService {
	
	@Autowired
	private ShopkeeperProductRepository shopkeeperProductRepository;

	@Override
	public ShopkeeperProduct saveProduct(ShopkeeperProduct shopkeeperproduct) {
		// TODO Auto-generated method stub
		return shopkeeperProductRepository.save(shopkeeperproduct);
	}

//	@Override
//	public List<ShopkeeperProduct> getAllProducts() {
//		// TODO Auto-generated method stub
//		return shopkeeperProductRepository.findAll();
//	}

	@Override
	public void updateProductByName(String shopkeeperproductname, Long shopkeeperproductquantity,
			Integer shopkeeperproductprice) {
		shopkeeperProductRepository.updateProductByName(shopkeeperproductname,shopkeeperproductquantity,shopkeeperproductprice);
		
	}

	@Override
	public void deleteProductByName(String shopkeeperproductname) {
		
		shopkeeperProductRepository.deleteProductByName(shopkeeperproductname);
		
	}

	@Override
	public ShopkeeperProduct addProductImage(ShopkeeperProduct shopkeeperProduct) {
		// TODO Auto-generated method stub
				return shopkeeperProductRepository.save(shopkeeperProduct);
	}

	@Override
	public ShopkeeperProduct getProductDetailsById(Integer shopkeeperproductid) {
		// TODO Auto-generated method stub
		return shopkeeperProductRepository.findById(shopkeeperproductid).get();
	}

	@Override
	public void deleteProductById(Integer shopkeeperproductid) {
		// TODO Auto-generated method stub
		shopkeeperProductRepository.deleteById(shopkeeperproductid);
	}

	@Override
	public List<ShopkeeperProduct> getProductDetail(boolean isSingleProductCheckout, Integer productId) {
		if(isSingleProductCheckout) {
			
			List<ShopkeeperProduct> list=new ArrayList<>();
			ShopkeeperProduct shopkeeperProduct=shopkeeperProductRepository.findById(productId).get();
			list.add(shopkeeperProduct);
		}else {
			
		}
		return new ArrayList<>();
		
	}

	@Override
	 public List<ShopkeeperProduct> getAllProducts(String searchKey, Sort sort) {
       if (searchKey.equals("")) {
           return shopkeeperProductRepository.findAll(sort);
       } else {
           return shopkeeperProductRepository.findByShopkeeperproductnameContainingIgnoreCase(searchKey, sort);
       }
   }

	}
