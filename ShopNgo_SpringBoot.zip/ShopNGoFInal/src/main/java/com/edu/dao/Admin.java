package com.edu.dao;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import org.hibernate.validator.constraints.UniqueElements;

@Entity
public class Admin {
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY) 
	private Integer adminid;
	@Column(length=20,nullable=false,unique=true)
	@NotBlank(message = "Admin name should not be empty")
	@NotEmpty(message = "Admin name should not be empty")
	private String adminname;
	@Size(min=6,max=14,message = "password should be minimum 6 character or maximum 14 character")
	@Pattern(
	        regexp = "^(?=.*[A-Z])(?=.*\\d)(?=.*[@#$%^&+=!]).+$",
	        message = "Password must have at least one capital letter, one number, and one special character."
	    )
	private String adminpassword;


public Admin() {
	super();
	// TODO Auto-generated constructor stub
}


public Admin(String adminname, String adminpassword) {
	super();
	this.adminname = adminname;
	this.adminpassword = adminpassword;
}


public Integer getAdminno() {
	return adminid;
}
public void setAdminno(Integer adminno) {
	this.adminid = adminno;
}
public String getAdminname() {
	return adminname;
}
public void setAdminname(String adminname) {
	this.adminname = adminname;
}
public String getAdminpassword() {
	return adminpassword;
}
public void setAdminpassword(String adminpassword) {
	this.adminpassword = adminpassword;
}


@Override
public String toString() {
	return "Admin [adminno=" + adminid + ", adminname=" + adminname + ", adminpassword=" + adminpassword + "]";
}

}
